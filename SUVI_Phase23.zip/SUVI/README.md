# SUVI — Android AI Voice Assistant
**Owner:** Ritesh

## Yeh package kya hai
Phase 1 scaffold: Voice input (SpeechRecognizer) + TTS output + basic Compose UI.
Mic dabao → bolo → Suvi sunke text dikhati hai aur bolke reply karti hai.

## Kaise chalayein
1. Android Studio khol kar `SUVI/` folder open karo (as existing project).
2. Gradle sync hone do.
3. Real phone ya emulator (mic ke saath) pe Run karo.
4. Mic button tap karo, permission allow karo, bolo — Suvi jo suna wo TTS me repeat karegi.

## File structure
```
SUVI/
├── app/src/main/java/com/ritesh/suvi/
│   ├── MainActivity.kt        (wiring: permission, speech, TTS, UI)
│   ├── voice/SpeechRecognizerHelper.kt
│   ├── tts/TextToSpeechHelper.kt
│   └── ui/SuviScreen.kt       (Compose screen: mic button, transcript, status)
├── app/src/main/AndroidManifest.xml
└── app/build.gradle.kts
```

## Ab tak kya ready hai (Phase 1 + 2 + 3 ✅)
- Mic permission handling
- Voice capture (Hindi/English — Hinglish free-form bhi capture hoga)
- Natural, neutral female TTS voice (best available device voice, no robotic pitch)
- App launch by spoken name ("WhatsApp khol do")
- Camera, Settings shortcuts (wifi/bluetooth/display/sound), media play/pause/next/prev
- YouTube search, Google web search
- Dialer open with number pre-filled (actual call = user confirms, safety by design)
- AI brain: anything that isn't a recognized command goes to Claude API for a natural reply
- Simple dark-themed Compose UI + one-time API key settings screen

## Apna AI API key chahiye
Settings screen me apna Anthropic API key daalna hoga (console.anthropic.com se milta hai,
paid/usage-based hai). Key sirf isi phone par local storage me rehti hai.

## Aage kya
| Phase | Kaam |
|---|---|
| 4 | AccessibilityService based automation, background/always-on listening service |
| 5 | "Hey Suvi" wake word, conversation memory, personality, final UI polish |

**Background listening note:** Abhi app khula hone par hi sunti hai. Poori tarah
background me (app band hoke bhi) sunna Android par ek foreground service +
persistent notification maangta hai (privacy rule hai, chhupa ke nahi ho sakta) —
ye Phase 4 me banayenge.

## Security note (already respected in code)
Password/OTP/banking jaisi sensitive actions ke liye is scaffold me koi
automatic control nahi hai — aage bhi ye sirf user confirmation ke baad
hi trigger honge, jaisa blueprint me tha.
