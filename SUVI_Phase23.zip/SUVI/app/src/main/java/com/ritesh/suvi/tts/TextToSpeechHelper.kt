package com.ritesh.suvi.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Phase 1: Basic TTS output.
 * Tries to pick a female-sounding voice from the device's available
 * voices; falls back to default if none is found.
 */
class TextToSpeechHelper(context: Context, private val onReady: () -> Unit = {}) {

    private var tts: TextToSpeech? = null
    private var isReady = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("hi", "IN")
                pickFemaleVoiceIfAvailable()
                // Neutral, natural tone — pitch shift na karo, robotic/over-the-top na lage
                tts?.setPitch(1.0f)
                tts?.setSpeechRate(0.95f)
                isReady = true
                onReady()
            }
        }
    }

    private fun pickFemaleVoiceIfAvailable() {
        val voices: Set<Voice>? = tts?.voices
        val candidates = voices?.filter { it.locale.language in listOf("hi", "en") }

        // Sabse natural sounding voice: female label + network/neural quality > local robotic voice
        val best = candidates
            ?.filter { !it.name.lowercase().contains("male") || it.name.lowercase().contains("female") }
            ?.maxByOrNull { voice ->
                var score = voice.quality
                if (voice.isNetworkConnectionRequired) score += 500
                score
            }

        best?.let { tts?.voice = it }
    }

    fun speak(text: String) {
        if (!isReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "suvi_utt")
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
