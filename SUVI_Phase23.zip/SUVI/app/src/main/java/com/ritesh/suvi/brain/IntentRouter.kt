package com.ritesh.suvi.brain

import com.ritesh.suvi.commands.PhoneCommands

/**
 * Simple rule-based router (Phase 2 + 3 bridge).
 * Command jaisa lage to seedha PhoneCommands se execute karo (fast, no AI needed).
 * Warna AI brain ko forward karo for a natural reply.
 */
sealed class RouteResult {
    data class CommandHandled(val spokenReply: String) : RouteResult()
    data class NeedsAi(val userText: String) : RouteResult()
}

class IntentRouter(private val phone: PhoneCommands) {

    fun route(text: String): RouteResult {
        val t = text.trim().lowercase()

        // Camera
        if (containsAny(t, "camera khol", "camera kholo", "open camera")) {
            phone.openCamera()
            return RouteResult.CommandHandled("Camera khol rahi hoon")
        }

        // Settings shortcuts
        if (containsAny(t, "wifi khol", "wifi on", "open wifi")) {
            phone.openSettings("wifi")
            return RouteResult.CommandHandled("Wifi settings khol rahi hoon")
        }
        if (containsAny(t, "bluetooth khol", "open bluetooth")) {
            phone.openSettings("bluetooth")
            return RouteResult.CommandHandled("Bluetooth settings khol rahi hoon")
        }
        if (containsAny(t, "settings khol", "open settings")) {
            phone.openSettings()
            return RouteResult.CommandHandled("Settings khol rahi hoon")
        }

        // Media control
        if (containsAny(t, "gaana bajao", "music bajao", "play song", "play music")) {
            phone.mediaPlayPause()
            return RouteResult.CommandHandled("Chalu kar rahi hoon")
        }
        if (containsAny(t, "gaana roko", "music roko", "pause", "stop song")) {
            phone.mediaPlayPause()
            return RouteResult.CommandHandled("Rok rahi hoon")
        }
        if (containsAny(t, "next gaana", "next song", "skip song")) {
            phone.mediaNext()
            return RouteResult.CommandHandled("Next song")
        }
        if (containsAny(t, "pichla gaana", "previous song")) {
            phone.mediaPrevious()
            return RouteResult.CommandHandled("Pichla gaana")
        }

        // YouTube
        for (prefix in listOf("youtube pe", "youtube par", "youtube search", "play")) {
            if (t.startsWith(prefix)) {
                val query = t.removePrefix(prefix).trim()
                if (query.isNotBlank()) {
                    phone.openYoutubeSearch(query)
                    return RouteResult.CommandHandled("YouTube pe $query dhoondh rahi hoon")
                }
            }
        }
        if (t.contains("youtube khol") || t.contains("open youtube")) {
            phone.openYoutubeSearch("")
            return RouteResult.CommandHandled("YouTube khol rahi hoon")
        }

        // Web search
        for (prefix in listOf("google pe search karo", "google me search karo", "search karo", "web search", "google search")) {
            if (t.startsWith(prefix)) {
                val query = t.removePrefix(prefix).trim()
                if (query.isNotBlank()) {
                    phone.openWebSearch(query)
                    return RouteResult.CommandHandled("$query search kar rahi hoon")
                }
            }
        }

        // Phone / dialer (actual call user khud confirm karega dialer me)
        for (prefix in listOf("call karo", "call kar do", "dial karo", "call")) {
            if (t.startsWith(prefix)) {
                val number = t.removePrefix(prefix).trim()
                if (number.any { it.isDigit() }) {
                    phone.openDialer(number)
                    return RouteResult.CommandHandled("Dialer khol rahi hoon, call button dabao")
                }
            }
        }

        // "X khol do" / "open X" -> treat X as app name
        val openAppPrefixes = listOf("khol do", "khol", "open")
        for (prefix in openAppPrefixes) {
            if (t.startsWith(prefix)) {
                val appName = t.removePrefix(prefix).trim()
                if (appName.isNotBlank() && phone.openApp(appName)) {
                    return RouteResult.CommandHandled("$appName khol rahi hoon")
                }
            }
            if (t.endsWith(prefix)) {
                val appName = t.removeSuffix(prefix).trim()
                if (appName.isNotBlank() && phone.openApp(appName)) {
                    return RouteResult.CommandHandled("$appName khol rahi hoon")
                }
            }
        }

        // Kuch match nahi hua -> AI brain se natural jawab lo
        return RouteResult.NeedsAi(text)
    }

    private fun containsAny(text: String, vararg phrases: String): Boolean =
        phrases.any { text.contains(it) }
}
