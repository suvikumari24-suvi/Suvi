package com.ritesh.suvi.commands

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent

/**
 * Phase 2: Phone control.
 * Sirf wahi actions jo Android normal apps ko allow karta hai —
 * root ya unrestricted control nahi (jaisa blueprint me clear tha).
 */
class PhoneCommands(private val context: Context) {

    /** App ka naam (jaisa user ne bola) se match karke launch karta hai. */
    fun openApp(spokenName: String): Boolean {
        val pm = context.packageManager
        val installedApps = pm.getInstalledApplications(android.content.pm.PackageManager.GET_META_DATA)

        val normalizedSpoken = spokenName.trim().lowercase()
        val match = installedApps.firstOrNull { appInfo ->
            val label = pm.getApplicationLabel(appInfo).toString().lowercase()
            label.contains(normalizedSpoken) || normalizedSpoken.contains(label)
        }

        val launchIntent = match?.let { pm.getLaunchIntentForPackage(it.packageName) }
        return if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        } else {
            false
        }
    }

    fun openCamera() {
        val intent = Intent("android.media.action.STILL_IMAGE_CAMERA").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    }

    fun openSettings(section: String? = null) {
        val action = when (section?.lowercase()) {
            "wifi", "vifi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "sound", "volume" -> Settings.ACTION_SOUND_SETTINGS
            "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
            "location", "gps" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }
        context.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun mediaPlayPause() = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
    fun mediaNext() = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
    fun mediaPrevious() = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    fun mediaStop() = dispatchMediaKey(KeyEvent.KEYCODE_MEDIA_STOP)

    /** YouTube app me search kholta hai; app na ho to browser me youtube.com search. */
    fun openYoutubeSearch(query: String) {
        val ytIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val resolved = context.packageManager.resolveActivity(ytIntent, 0)
        if (resolved != null) {
            context.startActivity(ytIntent)
        } else {
            val url = "https://www.youtube.com/results?search_query=" +
                Uri.encode(query)
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }

    /** Default browser me Google search kholta hai. */
    fun openWebSearch(query: String) {
        val url = "https://www.google.com/search?q=" + Uri.encode(query)
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /**
     * Dialer kholta hai number ke saath pre-filled — actual call user ko khud
     * dabana hoga (jaisa sensitive/phone actions ke liye confirmation chahiye,
     * blueprint ke security section jaisa).
     */
    fun openDialer(number: String) {
        val cleaned = number.filter { it.isDigit() || it == '+' }
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$cleaned"))
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun dispatchMediaKey(keyCode: Int) {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }
}
