package com.ritesh.suvi.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ApiKeyScreen(
    currentKey: String,
    onKeyChange: (String) -> Unit,
    onSave: () -> Unit,
    onSkip: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("SUVI ko AI dimaag chahiye", fontSize = 22.sp)
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "console.anthropic.com se apna API key le kar yahan daalo. " +
                "Ye sirf isi phone par save hoga.",
            fontSize = 14.sp
        )
        Spacer(modifier = Modifier.height(20.dp))
        OutlinedTextField(
            value = currentKey,
            onValueChange = onKeyChange,
            label = { Text("Anthropic API key") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row {
            Button(onClick = onSave) { Text("Save") }
            Spacer(modifier = Modifier.width(12.dp))
            OutlinedButton(onClick = onSkip) { Text("Baad me") }
        }
    }
}
