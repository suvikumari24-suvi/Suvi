package com.ritesh.suvi.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "suvi_settings")

/**
 * API key sirf isi phone par local storage me rehti hai — kahin bhejta nahi
 * (sirf seedha Anthropic API ko, jab AI se baat karni ho).
 */
object SettingsStore {
    private val API_KEY = stringPreferencesKey("anthropic_api_key")

    fun apiKeyFlow(context: Context): Flow<String?> =
        context.dataStore.data.map { it[API_KEY] }

    suspend fun saveApiKey(context: Context, key: String) {
        context.dataStore.edit { it[API_KEY] = key }
    }
}
