package com.ritesh.suvi.brain

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Phase 3: AI Brain.
 * Calls Google's Gemini API (free tier, no credit card needed) directly
 * from the phone using the user's own API key (entered once in Settings,
 * stored locally via SettingsStore).
 *
 * Owner ka apna Gemini API key chahiye — aistudio.google.com/apikey se
 * bilkul free milta hai (rate-limited, personal/testing use ke liye theek hai).
 */
class AiBrainClient(private val apiKey: String) {

    private val client = OkHttpClient()

    private val systemPrompt = """
        Tum SUVI ho — Ritesh ke liye bani ek friendly female AI voice assistant.
        Hindi, English, aur Hinglish sab me comfortably baat karo, jaisa user bole.
        Jawab chota aur natural rakho, jaise ek helpful dost baat karta hai — 
        lecture jaisa lamba jawab mat do jab tak zaroori na ho.
    """.trimIndent()

    /** Blocking call — caller ko background thread (coroutine) se invoke karna hai. */
    fun ask(userText: String): String {
        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            })
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", userText)))
                }
            ))
        }

        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            "gemini-2.5-flash:generateContent?key=$apiKey"

        val request = Request.Builder()
            .url(url)
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return "Sorry, AI se connect nahi ho paya (error ${response.code})"
                }
                val json = JSONObject(responseBody)
                val candidates = json.optJSONArray("candidates")
                val firstCandidate = candidates?.optJSONObject(0)
                val parts = firstCandidate?.optJSONObject("content")?.optJSONArray("parts")
                val texts = StringBuilder()
                if (parts != null) {
                    for (i in 0 until parts.length()) {
                        texts.append(parts.getJSONObject(i).optString("text"))
                    }
                }
                texts.toString().ifBlank { "Samajh nahi paayi, phir se bolo?" }
            }
        } catch (e: IOException) {
            "Internet check karo, Suvi connect nahi ho paayi"
        }
    }
}
