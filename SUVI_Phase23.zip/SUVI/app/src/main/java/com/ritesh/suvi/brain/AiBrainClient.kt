package com.ritesh.suvi.brain

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

/**
 * Phase 3: AI Brain.
 * Calls Anthropic's Messages API directly from the phone using the user's
 * own API key (entered once in Settings, stored locally via SettingsStore).
 *
 * Owner ka apna Anthropic API key chahiye — console.anthropic.com se milta hai.
 * Ye paid API hai (per-request billing), free nahi.
 */
class AiBrainClient(private val apiKey: String) {

    private val client = OkHttpClient()

    private val systemPrompt = """
        Tum SUVI ho — Ritesh ke liye bani ek friendly female AI voice assistant.
        Hindi, English, aur Hinglish sab me comfortably baat karo, jaisa user bole.
        Jawab chota aur natural rakho, jaise ek helpful dost baat karta hai — 
        lecture jaisa lamba jawab mat do jab tak zaroori na ho.
    """.trimIndent()

    /** Blocking call — caller ko background thread (coroutine) se invoke karna hai. */
    fun ask(userText: String): String {
        val body = JSONObject().apply {
            put("model", "claude-haiku-4-5-20251001")
            put("max_tokens", 300)
            put("system", systemPrompt)
            put("messages", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("content", userText)
                }
            ))
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        return try {
            client.newCall(request).execute().use { response ->
                val responseBody = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return "Sorry, AI se connect nahi ho paya (error ${response.code})"
                }
                val json = JSONObject(responseBody)
                val content = json.getJSONArray("content")
                val texts = StringBuilder()
                for (i in 0 until content.length()) {
                    val block = content.getJSONObject(i)
                    if (block.optString("type") == "text") {
                        texts.append(block.optString("text"))
                    }
                }
                texts.toString().ifBlank { "Samajh nahi paayi, phir se bolo?" }
            }
        } catch (e: IOException) {
            "Internet check karo, Suvi connect nahi ho paayi"
        }
    }
}
