package com.ritesh.suvi

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.ritesh.suvi.brain.AiBrainClient
import com.ritesh.suvi.brain.IntentRouter
import com.ritesh.suvi.brain.RouteResult
import com.ritesh.suvi.commands.PhoneCommands
import com.ritesh.suvi.data.SettingsStore
import com.ritesh.suvi.tts.TextToSpeechHelper
import com.ritesh.suvi.ui.ApiKeyScreen
import com.ritesh.suvi.ui.SuviScreen
import com.ritesh.suvi.voice.SpeechRecognizerHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.first

/**
 * Phase 2 + 3: Phone control + AI brain, ek saath.
 * "Hey Suvi" wake word aur memory Phase 5 me aayenge.
 */
class MainActivity : ComponentActivity() {

    private lateinit var speechHelper: SpeechRecognizerHelper
    private lateinit var ttsHelper: TextToSpeechHelper
    private lateinit var phoneCommands: PhoneCommands
    private lateinit var intentRouter: IntentRouter

    private var isListening = mutableStateOf(false)
    private var recognizedText = mutableStateOf("")
    private var statusText = mutableStateOf("Tap the mic to talk to Suvi")
    private var apiKey = mutableStateOf("")
    private var showSettings = mutableStateOf(false)

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening() else statusText.value = "Mic permission ke bina Suvi sun nahi sakti"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        phoneCommands = PhoneCommands(this)
        intentRouter = IntentRouter(phoneCommands)

        ttsHelper = TextToSpeechHelper(this) {
            ttsHelper.speak("Hi, main Suvi hoon. Aapki kya madad kar sakti hoon?")
        }

        speechHelper = SpeechRecognizerHelper(
            context = this,
            onResult = { text -> handleRecognizedText(text) },
            onError = { err ->
                isListening.value = false
                statusText.value = "Error: $err"
            }
        )

        lifecycleScope.launch {
            val savedKey = SettingsStore.apiKeyFlow(this@MainActivity).first()
            apiKey.value = savedKey.orEmpty()
            showSettings.value = savedKey.isNullOrBlank()
        }

        setContent {
            if (showSettings.value) {
                ApiKeyScreen(
                    currentKey = apiKey.value,
                    onKeyChange = { apiKey.value = it },
                    onSave = {
                        lifecycleScope.launch {
                            SettingsStore.saveApiKey(this@MainActivity, apiKey.value)
                            showSettings.value = false
                        }
                    },
                    onSkip = { showSettings.value = false }
                )
            } else {
                SuviScreen(
                    isListening = isListening.value,
                    recognizedText = recognizedText.value,
                    statusText = statusText.value,
                    onMicClick = { onMicButtonClicked() }
                )
            }
        }
    }

    private fun handleRecognizedText(text: String) {
        recognizedText.value = text
        isListening.value = false

        when (val result = intentRouter.route(text)) {
            is RouteResult.CommandHandled -> {
                statusText.value = result.spokenReply
                ttsHelper.speak(result.spokenReply)
            }
            is RouteResult.NeedsAi -> {
                if (apiKey.value.isBlank()) {
                    statusText.value = "AI key set nahi hai — settings me daalo"
                    ttsHelper.speak("AI se baat karne ke liye pehle API key set karo")
                    return
                }
                statusText.value = "Soch rahi hoon..."
                lifecycleScope.launch(Dispatchers.IO) {
                    val reply = AiBrainClient(apiKey.value).ask(result.userText)
                    runOnUiThread {
                        statusText.value = reply
                        ttsHelper.speak(reply)
                    }
                }
            }
        }
    }

    private fun onMicButtonClicked() {
        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) startListening() else requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        isListening.value = true
        statusText.value = "Sun rahi hoon..."
        speechHelper.startListening(languageTag = "hi-IN")
    }

    override fun onDestroy() {
        speechHelper.destroy()
        ttsHelper.shutdown()
        super.onDestroy()
    }
}
