package com.ritesh.suvi.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SuviScreen(
    isListening: Boolean,
    recognizedText: String,
    statusText: String,
    onMicClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF10131A))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom
    ) {
        Text(
            text = "SUVI",
            color = Color(0xFFB388FF),
            fontSize = 40.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = statusText,
            color = Color.Gray,
            fontSize = 14.sp,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .padding(bottom = 40.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1F2A))
        ) {
            Text(
                text = if (recognizedText.isBlank()) "Kuch bolo, main sun rahi hoon..." else recognizedText,
                color = Color.White,
                fontSize = 18.sp,
                modifier = Modifier.padding(20.dp)
            )
        }

        Box(
            modifier = Modifier
                .size(84.dp)
                .clip(CircleShape)
                .background(if (isListening) Color(0xFFEF5350) else Color(0xFFB388FF)),
            contentAlignment = Alignment.Center
        ) {
            IconButtonMic(onClick = onMicClick)
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun IconButtonMic(onClick: () -> Unit) {
    IconButton(onClick = onClick) {
        Text(text = "🎙", fontSize = 28.sp)
    }
}
