package com.ritesh.suvi

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.ritesh.suvi.tts.TextToSpeechHelper
import com.ritesh.suvi.ui.SuviScreen
import com.ritesh.suvi.voice.SpeechRecognizerHelper

/**
 * Phase 1: Voice + TTS + basic UI.
 * "Hey Suvi" wake word aur AI brain Phase 3/5 me aayenge.
 */
class MainActivity : ComponentActivity() {

    private lateinit var speechHelper: SpeechRecognizerHelper
    private lateinit var ttsHelper: TextToSpeechHelper

    private var isListening = mutableStateOf(false)
    private var recognizedText = mutableStateOf("")
    private var statusText = mutableStateOf("Tap the mic to talk to Suvi")

    private val requestMicPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startListening() else statusText.value = "Mic permission ke bina Suvi sun nahi sakti"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        ttsHelper = TextToSpeechHelper(this) {
            ttsHelper.speak("Hi, main Suvi hoon. Aapki kya madad kar sakti hoon?")
        }

        speechHelper = SpeechRecognizerHelper(
            context = this,
            onResult = { text ->
                recognizedText.value = text
                isListening.value = false
                statusText.value = "Suno mila: \"$text\""
                // Phase 3 me yahan AI brain call hoga (intent detection + response)
                ttsHelper.speak("Aapne kaha: $text")
            },
            onError = { err ->
                isListening.value = false
                statusText.value = "Error: $err"
            }
        )

        setContent {
            SuviScreen(
                isListening = isListening.value,
                recognizedText = recognizedText.value,
                statusText = statusText.value,
                onMicClick = { onMicButtonClicked() }
            )
        }
    }

    private fun onMicButtonClicked() {
        val hasPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            startListening()
        } else {
            requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startListening() {
        isListening.value = true
        statusText.value = "Sun rahi hoon..."
        speechHelper.startListening(languageTag = "hi-IN")
    }

    override fun onDestroy() {
        speechHelper.destroy()
        ttsHelper.shutdown()
        super.onDestroy()
    }
}
