# SUVI — Android AI Voice Assistant
**Owner:** Ritesh

## Yeh package kya hai
Phase 1 scaffold: Voice input (SpeechRecognizer) + TTS output + basic Compose UI.
Mic dabao → bolo → Suvi sunke text dikhati hai aur bolke reply karti hai.

## Kaise chalayein
1. Android Studio khol kar `SUVI/` folder open karo (as existing project).
2. Gradle sync hone do.
3. Real phone ya emulator (mic ke saath) pe Run karo.
4. Mic button tap karo, permission allow karo, bolo — Suvi jo suna wo TTS me repeat karegi.

## File structure
```
SUVI/
├── app/src/main/java/com/ritesh/suvi/
│   ├── MainActivity.kt        (wiring: permission, speech, TTS, UI)
│   ├── voice/SpeechRecognizerHelper.kt
│   ├── tts/TextToSpeechHelper.kt
│   └── ui/SuviScreen.kt       (Compose screen: mic button, transcript, status)
├── app/src/main/AndroidManifest.xml
└── app/build.gradle.kts
```

## Ab tak kya ready hai (Phase 1 ✅)
- Mic permission handling
- Voice capture (Hindi/English — Hinglish free-form bhi capture hoga)
- Basic TTS reply
- Simple dark-themed Compose UI

## Aage kya (Phases 2–5)
| Phase | Kaam |
|---|---|
| 2 | App launch, settings shortcuts, camera, media control (Android Intents) |
| 3 | AI brain: STT text → AI API → intent detection → action + natural reply |
| 4 | AccessibilityService based automation (deeper phone control, permissions ke andar) |
| 5 | "Hey Suvi" wake word, conversation memory, personality, final UI polish |

## Security note (already respected in code)
Password/OTP/banking jaisi sensitive actions ke liye is scaffold me koi
automatic control nahi hai — aage bhi ye sirf user confirmation ke baad
hi trigger honge, jaisa blueprint me tha.
